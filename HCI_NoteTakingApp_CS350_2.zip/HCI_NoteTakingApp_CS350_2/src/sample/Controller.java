package sample;

import javafx.scene.control.TextArea;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.Button;
import javafx.scene.input.KeyEvent;
import sample.BlankNote;



import java.net.URL;
import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;



public class Controller implements Initializable {

    // These need to be binded to the sampleFXML file buttons

    @FXML
    private TextArea notesAreaTextArea;
    @FXML
    private Button exitButton;
    @FXML
    private Button newNoteButton;
    @FXML
    private ListView<Note> listView;


    //This is the observable list we will see on the left side of application which
    // will be a collection of all the current notes
    private Note selectedNote = new Note("");
    private final ObservableList<Note> notesList = FXCollections.observableArrayList(Note.extractor);
    private final BooleanProperty modifiedProperty = new SimpleBooleanProperty(false);
    private ChangeListener<Note> noteChangeListener;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //We can initialize it with a blank note
                //class defined for it
        BlankNote.makeBlankNote(notesList);

        //It is making me use a sorted list here, im not sure why??/
        //Maybe we can try to sort the notes ny date/or last access??
        SortedList<Note> noteList = new SortedList<>(notesList);

        listView.setItems(noteList);
        newNoteButton.defaultButtonProperty().set(true);


        listView.getSelectionModel().selectedItemProperty().addListener(
                noteChangeListener = (observable, oldValue, newEntry) -> {

                    //There is something going on here which is making the listview notes act as
                    //one note instead of separate notes

                    selectedNote = newEntry;
                    modifiedProperty.set(false);
                    if (newEntry != null) {
                        notesAreaTextArea.setText("this is new text");

                    }

                });

        autoSave();

    }
    @FXML
    public void createNewNote(){

        //Create a new Note
        Note newNote = new Note();
        newNote.setNote("Blank");
        //add it to the notes list
        notesList.add(newNote);

       //select it
        listView.getSelectionModel().selectLast();
    }


    //This method will set the modified property to be true whenever a key is pressed - i.e someone
    //types something in the notes area
    @FXML
    private void handleKeyAction(KeyEvent keyEvent) {
        modifiedProperty.set(true);

    }

    @FXML
    private void autoSave() {
       if (modifiedProperty.equals(true)) {

           Note selectedNote = listView.getSelectionModel().getSelectedItem();

           listView.getSelectionModel().selectedItemProperty().removeListener(noteChangeListener);
           selectedNote.setNote(notesAreaTextArea.getText());
           listView.getSelectionModel().selectedItemProperty().addListener(noteChangeListener);

       }

        modifiedProperty.set(false);
    }



    @FXML
    public void exitProgram(ActionEvent actionEvent) {

        // If there is going to be autosave, then -> exit

        // if there is no autosave - make a pop menu to save work befire quitting

        System.exit(1);

    }
}